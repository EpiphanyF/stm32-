#include "stm32f10x.h"                  // Device header
#include "oled.h"
#include "stdbool.h"

void Timer2_Init(void){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	TIM_TimeBaseInitTypeDef TimeInitStructure;
	TimeInitStructure.TIM_ClockDivision=TIM_CKD_DIV1;
	TimeInitStructure.TIM_CounterMode=TIM_CounterMode_Up;
	TimeInitStructure.TIM_Period=100-1;
	TimeInitStructure.TIM_Prescaler=7200-1;
	TimeInitStructure.TIM_RepetitionCounter=0;
	TIM_TimeBaseInit(TIM2,&TimeInitStructure);
	  
	TIM_ClearFlag(TIM2,ENABLE);
	
	TIM_ITConfig(TIM2,TIM_FLAG_Update,ENABLE);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	
	NVIC_InitTypeDef NVICInitStructure;
	NVICInitStructure.NVIC_IRQChannel=TIM2_IRQn;
	NVICInitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVICInitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVICInitStructure.NVIC_IRQChannelSubPriority=3;
	NVIC_Init(&NVICInitStructure);
	
	TIM_Cmd(TIM2,ENABLE);
}





uint32_t FreeRTOSRunTimeTicks;
void ConfigureTimeForRunTimeStats(void){
	FreeRTOSRunTimeTicks=0;

}




