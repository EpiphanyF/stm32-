#ifndef __KEY_H
#define __KEY_H

#define KEYDWN	GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_12) == 0
#define KEYUP	GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == 0
#define KEYMOD	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0
#define KEYPWR	GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11) == 0

#define KEYDWN_NUM  1
#define KEYUP_NUM   2
#define KEYMOD_NUM  3
#define KEYPWR_NUM	4


void Key_Init(void);
uint8_t Key_GetNum(void);

#endif
