#include "pulse.h"
#include "stdint.h"
#include "stdio.h"
#include "ADC.h"
 
uint8_t IBI;            
uint16_t usPulse[128];  
uint8_t  ucPos;         
 
void scaleData(void);
static void calculatePulse(uint8_t *pulse, uint16_t *maxValue);
uint16_t getArrayMax(uint16_t arr[], int size);
uint16_t getArrayMin(uint16_t arr[], int size); 
 
 void getPulse(uint8_t *pulse, uint16_t *maxValue)
 {
	 uint16_t usData,SIG;
	 *pulse = 0;
	 *maxValue = 0;
	 usData = AD_GetValue();
	 usPulse[ucPos++] = usData; 
	 if (ucPos>=128)        
	 {
		 ucPos = 0;
		 scaleData();           
		 calculatePulse(pulse, maxValue); 
	 }
 
//	 SIG = usData - 1500;    //ʹ��Processing��λ����
//	 printf("S%d\r\n",SIG);  //ʹ��Processing��λ����
 }
 
 void scaleData()
 {
	 uint8_t i;
	 uint16_t usMax, usMin, usDelter;
	 usMax = getArrayMax(usPulse, 128);
	 usMin = getArrayMin(usPulse, 128);
	 usDelter = usMax - usMin;
	 if(usDelter<200)
	 {
		 for(i=0;i<128;i++)
		   usPulse[i] = usDelter/2;
	 }
	 else 
	 {
		 for(i=0;i<128;i++)
	     usPulse[i] = usDelter*(usPulse[i]-usMin)/usDelter;
	 } 
 }
 
 
static void calculatePulse(uint8_t *pulse, uint16_t *maxValue)
{
	uint8_t i, firstTime, secondTime;
	uint8_t PrePulse, Pulse, IBI;
	uint16_t usMax, usMin, usMid;
	
	usMax = getArrayMax(usPulse, 128);
	usMin = getArrayMin(usPulse, 128);
	usMid = (usMax + usMin)/2;
	*maxValue = usMax;
	firstTime = secondTime = 0;
	
	for(i=0;i<128;i++)
	{
		PrePulse = Pulse;
		Pulse = (usPulse[i]>usMid)?1:0;    
 
		if(PrePulse == 0 && Pulse == 1)
		{
			if(!firstTime) firstTime = i;
			if(firstTime && firstTime <i)
			{
				secondTime = i;
				break;      
			}
		}
	}
	if((secondTime - firstTime)>0)
	  {
	     IBI = (secondTime-firstTime)*HEART_PERIOD;  //IBI
	     *pulse = 60*1000/((secondTime-firstTime)*HEART_PERIOD);    //BPM                 //BPM
	  }
	else
		*pulse = 0;
 
//	printf("BPM = %d SIG = %d\r\n\r\n",*pulse, *IBI);   //�������ڵ��Դ�
//	printf("B%d\r\n",*pulse);  //ʹ��Processing��λ����
//	printf("Q%d\r\n",IBI);     //ʹ��Processing��λ����
}
 
 uint16_t getArrayMax(uint16_t arr[], int size) 
{
    if (size == 0) return 0; 
 
    uint16_t max = arr[0]; 
    for (int i = 1; i < size; i++) 
	  {
        if (arr[i] > max) 
				{
            max = arr[i]; 
        }
    }
    return max; 
}
 
uint16_t getArrayMin(uint16_t arr[], int size)
{
    if (size == 0) return 255; 
    uint16_t min = arr[0]; //
    for (int i = 1; i < size; i++)
   {
        if (arr[i] < min)
		{
            min = arr[i]; 
        }
    }
    return min; 
} 
