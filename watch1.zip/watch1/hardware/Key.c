#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include <stdbool.h>
#include "key.h"
#include "oled.h"
/* 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key_Init(void)
{
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);		//开启GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);		//开启GPIOA的时钟
	
	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);						//将PB1和PB11引脚初始化为上拉输入
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_11;
	GPIO_Init(GPIOA, &GPIO_InitStructure);						//将PB1和PB11引脚初始化为上拉输入
}

//高位存储长按
//低位存储短按
uint8_t Key_GetNum(void)
{
	static bool upflag=1;
	static uint8_t keycnt=0;
	static uint8_t keynum=0;
	uint8_t keyreturn=0;
	
	if(KEYDWN==1||KEYMOD==1||KEYPWR==1||KEYUP==1){
		if(upflag){
			upflag=0;      //按键按下
			Delay_ms(10);  //消抖
			if(KEYDWN==1)keynum=KEYDWN_NUM;
			else if(KEYMOD==1)keynum=KEYMOD_NUM;
			else if(KEYUP==1)keynum=KEYUP_NUM;
			else if(KEYPWR==1)keynum=KEYPWR_NUM;
		}
		else 
			keycnt++;
	}
	else 
		upflag=1;          //按键抬起
	//高位录入
	if(keynum&&upflag){
		if(keycnt>20)
			keyreturn=keynum<<4;
		else
			keyreturn=keynum;
		keycnt=0;
		keynum=0;
	}
	Delay_ms(10);
	return keyreturn;
}
