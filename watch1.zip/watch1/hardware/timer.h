#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"                  // Device header

void Timer2_Init(void);
//freertos
void ConfigureTimeForRunTimeStats(void);
//game

#endif
