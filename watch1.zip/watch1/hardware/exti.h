#ifndef __MYEXTI_H
#define __MYEXTI_H

void MyEXTI_Init(void);

#endif
