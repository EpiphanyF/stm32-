#ifndef __AHT10_H
#define __AHT10_H


uint8_t AHT10_GetValue(uint8_t Mode);
void AHT10_TrigMeasu(void);
void AHT10_ReadCmd(void);
uint8_t AHT10_GetState(void);
void AHT10_I2C_Init(void);

#endif
