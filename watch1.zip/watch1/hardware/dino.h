#ifndef __DINO_H
#define __DINO_H

void ShowGameAnimate(void);
extern uint32_t score;
#endif
