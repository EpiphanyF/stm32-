#ifndef __APPHEART_H
#define __APPHEART_H 

#include "stm32f10x.h"                  // Device header


#define HEART_PERIOD    20    
 
extern uint16_t usPulse[128];  
extern uint8_t  ucPos;    
extern uint8_t IBI;
 
void getPulse(uint8_t *pulse, uint16_t *maxValue);
 
#endif
