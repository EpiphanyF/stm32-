#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "FreeRTOS.h"
#include "task.h"
#include "portmacro.h"
#include "LED.h"
#include "key.h"
#include "exti.h"
#include "timer.h"
#include "OLED.h"
#include "freertos_demo.h"
#include "myusart.h"

int main(void) 
{
	Serial_Init();
	LED_Init();
	OLED_Init();
	Key_Init();
	Delay_Init();
	Timer3_Init();
	demo();

	//MyEXTI_Init();
	while(1)
	{  
		
	}				

}





