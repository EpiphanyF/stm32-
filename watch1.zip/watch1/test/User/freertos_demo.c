#include "stm32f10x.h"                  // Device header
#include "freertos.h"
#include "task.h"
#include "LED.h"
#include "key.h"
#include "Delay.h"
#include <stdio.h>
#include "OLED.h"
#include "Timer.h"
#include "queue.h"
#include "semphr.h"
#include "myusart.h"
#include "event_groups.h"

#define START_TASK_STACK_SIZE  128
#define START_TASK_PRIO        1

#define TASK1_STACK_SIZE  128
#define TASK1_PRIO        2

#define TASK2_STACK_SIZE  128
#define TASK2_PRIO        3

#define TASK3_STACK_SIZE  128
#define TASK3_PRIO 		  3

TaskHandle_t start_task_handler;
TaskHandle_t task1_handler;
TaskHandle_t task2_handler;
TaskHandle_t task3_handler;
SemaphoreHandle_t semaphore1_handle=0;

void start_task(void* pvParamaeters);
void task1 (void* pvParamaeters);
void task2 (void* pvParamaeters);
void task3 (void* pvParamaeters);
	
void demo(void){	
	xTaskCreate((TaskFunction_t) 			start_task,
				( char *	   ) 			"start_task", 
				(configSTACK_DEPTH_TYPE) 	START_TASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				START_TASK_PRIO,
				(TaskHandle_t * ) 			&start_task_handler );
	vTaskStartScheduler();
}


void start_task(void* pvParamaeters){

	taskENTER_CRITICAL();
	xTaskCreate((TaskFunction_t) 			task1,
				( char *	   ) 			"task1", 
				(configSTACK_DEPTH_TYPE) 	TASK1_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				TASK1_PRIO,
				(TaskHandle_t * ) 			&task1_handler );

//	xTaskCreate((TaskFunction_t) 			task2,
//				( char *	   ) 			"task2", 
//				(configSTACK_DEPTH_TYPE) 	START_TASK_STACK_SIZE,
//				(void * ) 					NULL,
//				(UBaseType_t) 				TASK2_PRIO,
//				(TaskHandle_t * ) 			&task2_handler );
				
//	xTaskCreate((TaskFunction_t) 			task3,
//				( char *	   ) 			"task3", 
//				(configSTACK_DEPTH_TYPE) 	START_TASK_STACK_SIZE,
//				(void * ) 					NULL,
//				(UBaseType_t) 				TASK3_PRIO,
//				(TaskHandle_t * ) 			&task3_handler );
				
	vTaskDelete(start_task_handler);
	taskEXIT_CRITICAL();
}

void task1 (void* pvParamaeters){
	uint8_t *buffer=NULL;
    
	while(1){
		uint8_t key=Key_GetNum();
		if(key==1){
			buffer=pvPortMalloc(10);
			if(buffer!=NULL)
				Serial_Printf("application successful\r\n");
			else
				Serial_Printf("application failed\r\n");
		}
		if(key==2){
			if(buffer!=NULL){
				vPortFree(buffer);
				Serial_Printf("release success\r\n");
			}else
				Serial_Printf("release failed\r\n");
		}
		if(key==3){
			Serial_Printf("remaining memory:%d\r\n",xPortGetFreeHeapSize());
		}                                

		vTaskDelay(10);
 	}
}


void task2 (void* pvParamaeters){

	int i;
	BaseType_t err=0;
	while(1){
		err=xSemaphoreTake(semaphore1_handle,portMAX_DELAY);
        if(err==pdTRUE){
			Serial_Printf("successfully take\r\n");
		}else{
			Serial_Printf("timeout:%d\r\n",i++);
		}
		vTaskDelay(10);
	}
}

void task3 (void* pvParamaeters){
	while(1){

	}
}


