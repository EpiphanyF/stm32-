#ifndef __TIMER_H
#define __TIMER_H
void Timer2_Init(void);
void Timer3_Init(void);
void ConfigureTimeForRunTimeStats(void);

#endif
