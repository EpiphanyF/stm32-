#include "stm32f10x.h"                  // Device header
#include "freertos_demo.h"
/*
		PA1->LED
		PB12->KEYNUM_DWN
		PB14->KEYNUM_UP
		PA8->KEYNUM_MOD
		PA11->KEYNUM_PWR
		PA6->AHT10_SDA
		PA7->AHT10_SCL
*/
int main(void) 
{
	Watch_Init();
	demo();
	
	while(1)
	{
	}
}


