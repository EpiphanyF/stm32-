#ifndef __FREERTOS_DEMO_H
#define __FREERTOS_DEMO_H

#define START_TASK_STACK_SIZE  128
#define START_TASK_PRIO        1

#define KEYTASK_STACK_SIZE  	  128
#define KEYTASK_PRIO         	  4

#define MainMenuTASK_STACK_SIZE   128
#define MainMenuTASK_PRIO         3

#define TimeSetTASK_STACK_SIZE    128
#define TimeSetTASK_PRIO 		  3

#define AlarmSetTASK_STACK_SIZE   128
#define AlarmSetTASK_PRIO 	      3

#define TimeCheckTASK_STACK_SIZE  128
#define TimeCheckTASK_PRIO        3

#define AlarmDoTASK_STACK_SIZE    128
#define AlarmDoTASK_PRIO          3

#define SecondTASK_STACK_SIZE 	  128
#define SecondTASK_PRIO        	  3

#define GameStartTASK_STACK_SIZE  128
#define GameStartTASK_PRIO        3

#define GameSetupTASK_STACK_SIZE  128
#define GameSetupTASK_PRIO        3

#define HeartStartTASK_STACK_SIZE 128
#define HeartStartTASK_PRIO       3


#define MainFunction_Total		3
#define MainFunction_Main		0
#define MainFunction_CLK		1
#define MainFunction_GME		2
#define MainFunction_HEART		3

#define SubFunction_CLK_TimeSet	0
#define SubFunction_CLK_AlarSet	1
#define SubFunction_CLK_Second	2

#define SubFunction_GME_Start	0
#define SubFunction_GME_Setup	1

#define SubFunction_Heart_Start 0

void demo(void);
void Watch_Init(void);

void PRE_SLEEP_PROCESSING(void);
void POST_SLEEP_PROCESSING(void);

#endif
