#include "stm32f10x.h"                  // Device header
#include "freertos.h"
#include "task.h"
#include "LED.h"
#include "key.h"
#include "Delay.h"
#include <stdbool.h>
#include "OLED.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "rtc.h"
#include "dino.h"
#include "AHT10.h"
#include "pulse.h"

void Suspendtask(void);

void MainFunction_Display(uint8_t mainFunction);
void SubFunction_Display(uint8_t mainFunction);
void SubFunction_Execute(uint8_t mainFunction,uint8_t subFunction);
uint8_t GetMaxSubFunction(uint8_t mainFunction);

QueueHandle_t queueKeyHandler;
TimerHandle_t Singletimer_handler;


int8_t currentMainFunction=0;
uint8_t currentSubFunction=0;


//TICKLESSģʽ
void configPRE_SLEEP_PROCESSING(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,DISABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,DISABLE);
}

void configPOST_SLEEP_PROCESSING(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
}

TaskHandle_t MainMenutask_handler;
void MainMenutask(void* pvParamaeters){
	uint8_t keynum;
		
	RTC_Set(2024,1,1,20,17,33); 

	OLED_Clear();
	OLED_Update();
	while(1){
		
		//��ʪ����ʾ
		AHT10_TrigMeasu();
		AHT10_ReadCmd();
		
		uint8_t tempertrue=AHT10_GetValue(1);
		uint8_t humidity=AHT10_GetValue(0);

		OLED_ShowNum(64,1,tempertrue,2,6);
		OLED_ShowImage(77,1,8,8,temp_char);

		OLED_ShowNum(93,1,humidity,2,6);
		OLED_ShowString(107,1,"%RH",6);

			
		//ʱ����ʾ
		OLED_ShowNum(64,18,calendar.hour,2,8);
		OLED_ShowChar(81,18,':',8);
		OLED_ShowNum(90,18,calendar.min,2,8);		
		OLED_ShowChar(107,26,':',6);
		OLED_ShowNum(113,25,calendar.sec,2,6);
		
		OLED_ShowNum(64,10,calendar.w_year,4,6); //ȥ����ʪ��YΪ8
		OLED_ShowNum(93,10,calendar.w_month,2,6);
		OLED_ShowNum(113,10,calendar.w_date,2,6);
		OLED_ShowChinese(72,38,"��");
		OLED_ShowChinese(88,38,"��");
		
		OLED_ShowImage(1,1,57,50,ow);
		switch(calendar.week){
			case 0:
				OLED_ShowChinese(104,38,"��");
				break;
			case 1:
				OLED_ShowChinese(104,38,"һ");
				break;
			case 2:
				OLED_ShowChinese(104,38,"��");
				break;
			case 3:
				OLED_ShowChinese(104,38,"��");
				break;
			case 4:
				OLED_ShowChinese(104,38,"��");
				break;
			case 5:
				OLED_ShowChinese(104,38,"��");
				break;
			case 6:
				OLED_ShowChinese(104,38,"��");
				break;
		}
	    OLED_Update();
		
		//�����ֵ����ֹӰ���������񣨿��ܸ���������ȼ��ϵͣ�
		xQueueReceive(queueKeyHandler,&keynum,0);
				
	    vTaskDelay(pdMS_TO_TICKS(500));
	}
}
 
TaskHandle_t TimeSettask_handler;
void TimeSettask(void* pvParamaeters){
	
	OLED_Clear();
	OLED_Update();
	uint16_t datetime[7]={0};
	static uint8_t timesetpos=0;
	uint8_t keynum=0;
	bool FlashFlag=0;
	
		datetime[0]=calendar.w_year;
		datetime[1]=calendar.w_month;
		datetime[2]=calendar.w_date;
		datetime[3]=calendar.hour;
		datetime[4]=calendar.min;
		datetime[5]=calendar.sec;	
	
	while(1){
		//��¼��ǰʱ��
	
		
		//��ʾ
		OLED_ShowNum(64,18,datetime[3],2,8);
		OLED_ShowChar(81,18,':',8);
		OLED_ShowNum(90,18,datetime[4],2,8);		
		OLED_ShowChar(107,26,':',6);
		OLED_ShowNum(113,25,datetime[5],2,6);
		
		OLED_ShowNum(64,10,datetime[0],4,6);
		OLED_ShowNum(93,10,datetime[1],2,6);
		OLED_ShowNum(113,10,datetime[2],2,6);
		OLED_ShowChinese(72,38,"��");
		OLED_ShowChinese(88,38,"��");		
		switch(datetime[3]){
			case 0:
				OLED_ShowChinese(104,38,"��");
				break;
			case 1:
				OLED_ShowChinese(104,38,"һ");
				break;
			case 2:
				OLED_ShowChinese(104,38,"��");
				break;
			case 3:
				OLED_ShowChinese(104,38,"��");
				break;
			case 4:
				OLED_ShowChinese(104,38,"��");
				break;
			case 5:
				OLED_ShowChinese(104,38,"��");
				break;
			case 6:
				OLED_ShowChinese(104,38,"��");
				break;
		}
	    OLED_Update();

		
		OLED_ShowString(10,10,"TimeSet",6);
		OLED_Update();
		
        //ʱ����˸
		if(FlashFlag){
			switch (timesetpos){
				case 0:
					OLED_ShowString(64,10,"    ",6);
					break;
				case 1:
					OLED_ShowString(93,10,"  ",6);
					break;
				case 2:
					OLED_ShowString(113,10,"  ",6);
					break;
				case 3:
					OLED_ShowString(64,18,"  ",8);
					break;
				case 4:
					OLED_ShowString(90,18,"  ",8);
					break;
				case 5:
					OLED_ShowString(113,25,"  ",8);
					break;
			}	
		}
		OLED_Update();
		//���ռ�ֵ
		if(xQueueReceive(queueKeyHandler,&keynum,0)==pdTRUE){
			switch(keynum){
				case KEYUP_NUM:
					datetime[timesetpos]++;
					numLimit(datetime,timesetpos);
				    break;
				case KEYDWN_NUM:
					datetime[timesetpos]--;
					numLimit(datetime,timesetpos);
					break;
				case KEYPWR_NUM:
					if(++timesetpos>5){
						timesetpos=0;
						RTC_Set(datetime[0],datetime[1],datetime[2],datetime[3],datetime[4],datetime[5]);
					}
					break;
			}
		}
		FlashFlag=!FlashFlag;

		vTaskDelay(pdMS_TO_TICKS(500));
	}
}


TaskHandle_t AlarmSettask_handler;
uint16_t alarmset[6]={0};
void AlarmSettask(void* pvParamaeters){
	OLED_Clear();
	OLED_Update();	
	bool FlashFlag=0;
	uint8_t alarmsetpos=0;
	uint8_t keynum=0;
	alarmset[3]=calendar.hour;
	alarmset[4]=calendar.min;
	alarmset[5]=calendar.sec;
	


	while(1){
		//��ʾ
		OLED_ShowString(10,10,"AlarmSet",6);
		OLED_Update();
		
		OLED_ShowNum(27,20,alarmset[3],2,8);
		OLED_ShowChar(46,20,':',8);
		OLED_ShowNum(57,20,alarmset[4],2,8);
		OLED_ShowChar(76,20,':',8);
   		OLED_ShowNum(87,20,alarmset[5],2,8);
		//��˸
		if(FlashFlag){
			
		    OLED_ShowString(27+alarmsetpos*30,20,"  ",8);
		
		}
		OLED_Update();
		//��������
		if(xQueueReceive(queueKeyHandler,&keynum,0)==pdTRUE){
			LED1_ON();
			switch(keynum){
				case KEYUP_NUM://3Ϊƫ��ֵ
					alarmset[alarmsetpos+3]++;
					numLimit(alarmset,alarmsetpos+3);
					break;
				case KEYDWN_NUM:
					alarmset[alarmsetpos+3]--;
					numLimit(alarmset,alarmsetpos+3);
					break;
				case KEYPWR_NUM:
					if(++alarmsetpos>3){
						alarmsetpos=0;
					}
					break;
			}
		
		}
		FlashFlag=!FlashFlag;
		vTaskDelay(pdMS_TO_TICKS(500));
	}
}




TaskHandle_t Keytask_handler;
void Keytask(void* pvParamaeters){
	OLED_Clear();
	OLED_Update();
	uint8_t ucKeyNum=0;
	
    bool isMainMenu=true;
	bool isSubMenu=false;//�Ƿ�ǰ��С�˵�
	//��������
	queueKeyHandler=xQueueCreate(1,sizeof(uint8_t));
	
	while(1){
 		ucKeyNum=Key_GetNum();
		//����		
		if(ucKeyNum>>4){
			//PWR�ػ�
			if((ucKeyNum>>4)==KEYPWR_NUM){
					OLED_Clear();
					OLED_Update();
					
					Suspendtask();
				
					__WFI();								//ִ��WFIָ�CPU˯�ߣ����ȴ��жϻ���	
			}
		}
		//�̰�MOD
		ucKeyNum&=0x0f;
		if(ucKeyNum==KEYMOD_NUM){
			Suspendtask();
			if(++currentMainFunction>MainFunction_Total)
				currentMainFunction=MainFunction_Main;
			
			currentSubFunction=0;//����С����״̬
			isSubMenu=false;//�˳�С����״̬
			isMainMenu=true;//�������˵�״̬
			
			MainFunction_Display(currentMainFunction);//��ʾ����
		}
		//�Ƿ������˵�
		if(isMainMenu){
			//�̰�PWR
			if(ucKeyNum==KEYPWR_NUM){
				if(!isSubMenu){
					isSubMenu=true;//����С���ܲ˵�
					currentSubFunction=0;//����ʱ����С����״̬
					SubFunction_Display(currentMainFunction);//��ʾС����

				}else {
					//ȷ�Ͻ���ѡ�е�С����
					OLED_Clear();
					SubFunction_Execute(currentMainFunction,currentSubFunction);//ִ��С����
					isMainMenu=false;
				}
			}
			//С���ܲ˵��ڴ�������ѡ��
			if(isSubMenu){
				if(ucKeyNum==KEYUP_NUM){
					currentSubFunction++;
					if(currentSubFunction>=GetMaxSubFunction(currentMainFunction))
						currentSubFunction=0;
					SubFunction_Display(currentMainFunction);

				}else if(ucKeyNum==KEYDWN_NUM){
					if(currentSubFunction==0)
						currentSubFunction=GetMaxSubFunction(currentMainFunction)-1;
					else
						currentSubFunction--;
					SubFunction_Display(currentMainFunction);
				}
				OLED_Update();
			}
		}else if(ucKeyNum!=0){ //��������
			xQueueSendToBack(queueKeyHandler,&ucKeyNum,100);
			//���ö�ʱ��
			//xTimerStart()
		}
		
		//OLED_ShowNum(1,50,currentSubFunction,1,8);
		OLED_Update();
		
	    vTaskDelay(pdMS_TO_TICKS(100));
	}
}

TaskHandle_t AlarmDotask_handler;
void AlarmDotask(void* pvParamaeters){
	
	uint8_t alarmflag=0;
	uint8_t keynum=0;
	OLED_Clear();
	OLED_Update();
	while(1){
		//����ʱ��
		if(ulTaskNotifyTake(pdTRUE,0))
			alarmflag=10;
		if(alarmflag){
			Suspendtask();
			//����ִ��
			OLED_ShowChinese(33,10,"��������");
			OLED_ShowImage(50,30,30,30,clock1);
			OLED_Update();
			
			vTaskDelay(pdMS_TO_TICKS(500));
			
			OLED_ShowString(33,10,"        ",8);
			OLED_ShowImage(50,30,30,30,clock2);
			OLED_Update();
			LED1_ON();
			
			vTaskDelay(pdMS_TO_TICKS(500));
			
			alarmflag--;      //����ʱ
			
			//���ⰴ��������ǰ��������
			if(xQueueReceive(queueKeyHandler,&keynum,0)==pdTRUE)
				alarmflag=0;
			//����
			if(alarmflag==0){
				LED1_OFF();
				OLED_Clear();
				OLED_Update();
			}
		
		}
		else
			vTaskDelay(pdMS_TO_TICKS(500));
	}
}	

TaskHandle_t TimeChecktask_handler;
void TimeChecktask(void* pvParamaeters){
	while(1){
		//����ʱ��
		RTC_Get();
		//ȷ��ʱ��
		if(alarmset[3]==calendar.hour&&alarmset[4]==calendar.min&&alarmset[5]==calendar.sec){
			Suspendtask();
			xTaskNotifyGive(AlarmDotask_handler);
		}
		vTaskDelay(pdMS_TO_TICKS(500));
	}

}

TaskHandle_t Secondtask_handler;
void Secondtask(void* pvParamaeters){
	
	uint8_t second[3]={0};
	bool runflag=0;
	uint8_t keynum=0;
	//TickType_t timenum;
	
	OLED_Clear();
	OLED_Update();
	//timenum=xTaskGetTickCount();
	
    while(1){  
		OLED_ShowNum(27,20,second[0],2,8);
		OLED_ShowNum(57,20,second[1],2,8);
		OLED_ShowNum(87,20,second[2],2,8);
	    OLED_Update();
		
		if(xQueueReceive(queueKeyHandler,&keynum,0)==pdTRUE)
			if(keynum==KEYPWR_NUM)
				runflag=!runflag;
		
		if(runflag){
			//timenum=xTaskGetTickCount();
			second[2] += 1;
			if(second[2]>99){
				second[2]=0;
				second[1]++;
				if(second[1]>59){
					second[1]=0;
					second[0]++;
					if(second[0]>59)second[0]=0;
				}
			}
			vTaskDelay(pdMS_TO_TICKS(10));  // ÿ���ӳ�10����  
			//vTaskDelayUntil(&timenum,pdMS_TO_TICKS(0.1));
		
		}else{			
			vTaskDelay(pdMS_TO_TICKS(500));
		}
		

	}
}

TaskHandle_t GameStarttask_handler;
void GameStarttask(void* pvParamaeters){
	
	uint32_t game_level=0;
	uint8_t game_delay=100;
	while(1){
		
		if(xTaskNotifyWait(0,0xFFFFFFFF,&game_level,0)==pdTRUE){
			switch(game_level){
				case 0:
					game_delay=100;
					break;
				case 1:
					game_delay=80;
					break;
				case 2:
					game_delay=60;
					break;
				case 3:
					game_delay=40;
					break;
				case 4:
					game_delay=20;
					break;
				case 5:
					game_delay=0;
					break;
			}
		}
		
		if(score%100==0&&score>=100&&game_delay>0){
			game_delay--;
		}
		
		ShowGameAnimate();
		OLED_Update();
		
		vTaskDelay(pdMS_TO_TICKS(game_delay));
	}
}

TaskHandle_t GameSetuptask_handler;
void GameSetuptask(void* pvParamaeters){
	
	uint32_t game_record=0;
	uint8_t game_level=0;
	uint8_t keynum=0;
	while(1){
		OLED_ShowChinese(1,5,"��߷�");
		OLED_ShowChinese(1,25,"�Ѷ�����");
		OLED_ShowNum(85,6,game_record,5,8);
		OLED_ShowNum(117,25,game_level,1,8);
		OLED_Update();
		if(score>game_record)
			game_record=score;
        
		if(xQueueReceive(queueKeyHandler,&keynum,0)==pdTRUE){
			switch(keynum){
				case KEYDWN_NUM:
					if(game_level>0)
						game_level--;
					break;
				case KEYUP_NUM:
					if(game_level<5)
						game_level++;
					break;
			}
		}
		
		//������Ϣ
		xTaskNotify(GameStarttask_handler,game_level,eSetValueWithOverwrite);
	    vTaskDelay(pdMS_TO_TICKS(100));
	}
}

TaskHandle_t HeartStarttask_handler;
void HeartStarttask(void* pvParamaeters){
	
	uint8_t keynum=0;
	TickType_t waketime;
	bool runflag=0;
	uint8_t pulse=0;    //���
	uint16_t maxvalue=0;//����
	while(1){
		if(xQueueReceive(queueKeyHandler,&keynum,0))
			runflag=!runflag;
		
		if(runflag){
			waketime=xTaskGetTickCount();
			
			ADC_SoftwareStartConvCmd(ADC1, ENABLE);//��������		
			getPulse(&pulse,&maxvalue);
			
			//һ�ֲɼ�
			if(ucPos==0){
				OLED_Clear();
				for(int i=0;i<128;i++){
					OLED_DrawPoint(i,64-usPulse[i]*24/maxvalue);
					OLED_Update();
				}
				OLED_ShowNum(1,1,pulse,4,6);
				OLED_Update();
				
			}
		vTaskDelayUntil(&waketime,pdMS_TO_TICKS(20));
			
		}else{
			ADC_SoftwareStartConvCmd(ADC1, DISABLE);//��������
			OLED_Clear();
			OLED_Update();
			vTaskDelay(pdMS_TO_TICKS(500));
		}
	}
}

void Suspendtask(void){
	
	vTaskSuspend(MainMenutask_handler);
    vTaskSuspend(TimeSettask_handler);
	vTaskSuspend(AlarmSettask_handler);
	vTaskSuspend(Secondtask_handler);
	vTaskSuspend(GameStarttask_handler);
	vTaskSuspend(GameSetuptask_handler);
	vTaskSuspend(HeartStarttask_handler);
	
	OLED_Clear();
	OLED_Update();
}


//��ȡ��ǰ���ܵ�С��������
uint8_t GetMaxSubFunction(uint8_t mainFunction){
	switch(mainFunction){
		case MainFunction_Main:
			return 0;
		case MainFunction_CLK:
			return 3;
		case MainFunction_GME:
			return 2;
		case MainFunction_HEART:
			return 1;
		default:
			return 0;
	}
}

//���ܽ�����ʾ
void MainFunction_Display(uint8_t mainFunction) {  
    OLED_Clear();  // ��� OLED ��ʾ��  
    
    // ����Ч���������ƶ�  
    for (int16_t offset = 0; offset < 128; offset += 5) { // ÿ������4������  
        OLED_Clear();  // ����  
        
        // ���Ƶ�ǰ����  
        switch (mainFunction) {  
            case MainFunction_Main:  
				vTaskResume(MainMenutask_handler);
                break;  
            case MainFunction_CLK:  
                OLED_ShowImage(1, 1, 60, 60, bigclock);   
                OLED_ShowChinese(82, 22, "ʱ��");  
                break;  
            case MainFunction_GME:  
				OLED_ShowImage(1 - offset, 1, 60, 60, bigclock);   
                OLED_ShowChinese(82 - offset, 22, "ʱ��");  
                OLED_ShowImage(128 - offset, 1, 60, 60, biggame);   
                OLED_ShowChinese(209 - offset, 22, "��Ϸ");  
                break; 
			case MainFunction_HEART:
				OLED_ShowImage(1 - offset, 1, 60, 60, biggame);   
                OLED_ShowChinese(82 - offset, 22, "��Ϸ");  
				OLED_ShowImage(128 - offset ,5,58,50,heart);	
                OLED_ShowChinese(209 - offset, 22, "����");  
				break;
            default:  
                OLED_ShowString(1 - offset, 1, "error", 8); 
                break;  
        }  
        
        OLED_Update();  // ������ʾ  
        vTaskDelay(pdMS_TO_TICKS(1));  // ���ƶ����ٶ�  
    }  
    
}  


//С���ܽ�����ʾ
void SubFunction_Display(uint8_t mainFunction){
	OLED_Clear();
	uint8_t maxSubFunction=GetMaxSubFunction(mainFunction);
	
	//��ʾ��ͷ
	for(uint8_t i=0;i<maxSubFunction;i++){
		if(i==currentSubFunction){
			OLED_ShowChar(72,i*20+10,'-',6);
			OLED_ShowChar(78,i*20+10,'>',6);
		}
	}
	
	//��ʾС��������
	switch(mainFunction){
		case MainFunction_CLK:
			OLED_ShowImage(1,1,60,60,bigclock);
			OLED_ShowChinese(92,5,"��t");
			OLED_ShowChinese(92,25,"�m�t");
			OLED_ShowChinese(92,45,"���");
			break;
		case MainFunction_GME:
			OLED_ShowImage(1,1,60,60,biggame);
			OLED_ShowChinese(92,5,"��ʼ");
			OLED_ShowChinese(92,25,"����");
			break;
		case MainFunction_HEART:
			OLED_ShowImage(1,5,58,50,heart);	
			OLED_ShowChinese(92,5,"��ʼ");
	}
	OLED_Update();

}

//С����ִ��
void SubFunction_Execute(uint8_t mainFunction,uint8_t subFunction){
	switch(mainFunction){
		case MainFunction_CLK:
			switch(subFunction){
				case SubFunction_CLK_TimeSet:
					vTaskResume(TimeSettask_handler);
                    break;
				case SubFunction_CLK_AlarSet:
					vTaskResume(AlarmSettask_handler);
					break;
				case SubFunction_CLK_Second:
					vTaskResume(Secondtask_handler);
					break;
			}
			break;
		case MainFunction_GME:
			switch(subFunction){
				case SubFunction_GME_Start:
					vTaskResume(GameStarttask_handler);
					break;
				case SubFunction_GME_Setup:
					vTaskResume(GameSetuptask_handler);
					break;
			}
			break;
		case MainFunction_HEART:
			switch(subFunction){
				case SubFunction_Heart_Start:
					vTaskResume(HeartStarttask_handler);
					break;
			}
			break;
	}
}

TaskHandle_t start_task_handler;
void start_task(void* pvParamaeters){

	taskENTER_CRITICAL();
	xTaskCreate((TaskFunction_t) 			Keytask,
				( char *	   ) 			"Keytask", 
				(configSTACK_DEPTH_TYPE) 	KEYTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				KEYTASK_PRIO,
				(TaskHandle_t * ) 			&Keytask_handler );

	xTaskCreate((TaskFunction_t) 			MainMenutask,
				( char *	   ) 			"MainMenutask", 
				(configSTACK_DEPTH_TYPE) 	MainMenuTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				MainMenuTASK_PRIO,
				(TaskHandle_t * ) 			&MainMenutask_handler );
				
	xTaskCreate((TaskFunction_t) 			TimeSettask,
				( char *	   ) 			"TimeSettask", 
				(configSTACK_DEPTH_TYPE) 	TimeSetTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				TimeSetTASK_PRIO,
				(TaskHandle_t * ) 			&TimeSettask_handler );
			
   	xTaskCreate((TaskFunction_t) 			AlarmSettask,
				( char *	   ) 			"AlarmSettask", 
				(configSTACK_DEPTH_TYPE) 	AlarmSetTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				AlarmSetTASK_PRIO,
				(TaskHandle_t * ) 			&AlarmSettask_handler );

  	xTaskCreate((TaskFunction_t) 			TimeChecktask,
				( char *	   ) 			"TimeChecktask", 
				(configSTACK_DEPTH_TYPE) 	TimeCheckTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				TimeCheckTASK_PRIO,
				(TaskHandle_t * ) 			&TimeChecktask_handler );
			
  	xTaskCreate((TaskFunction_t) 			AlarmDotask,
				( char *	   ) 			"AlarmDotask", 
				(configSTACK_DEPTH_TYPE) 	AlarmDoTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				AlarmDoTASK_PRIO,
				(TaskHandle_t * ) 			&AlarmDotask_handler );
				
	xTaskCreate((TaskFunction_t) 			Secondtask,
				( char *	   ) 			"Secondtask", 
				(configSTACK_DEPTH_TYPE) 	SecondTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				SecondTASK_PRIO,
				(TaskHandle_t * ) 			&Secondtask_handler );
				
	xTaskCreate((TaskFunction_t) 			GameStarttask,
				( char *	   ) 			"GameStarttask", 
				(configSTACK_DEPTH_TYPE) 	GameStartTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				GameStartTASK_PRIO,
				(TaskHandle_t * ) 			&GameStarttask_handler );
	
	xTaskCreate((TaskFunction_t) 			GameSetuptask,
				( char *	   ) 			"GameSetuptask", 
				(configSTACK_DEPTH_TYPE) 	GameSetupTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				GameSetupTASK_PRIO,
				(TaskHandle_t * ) 			&GameSetuptask_handler );
				
	xTaskCreate((TaskFunction_t) 			HeartStarttask,
				( char *	   ) 			"HeartStarttask", 
				(configSTACK_DEPTH_TYPE) 	HeartStartTASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				HeartStartTASK_PRIO,
				(TaskHandle_t * ) 			&HeartStarttask_handler );
				
	vTaskDelete(start_task_handler);
				
    vTaskSuspend(TimeSettask_handler);
	vTaskSuspend(AlarmSettask_handler);
	vTaskSuspend(Secondtask_handler);
	vTaskSuspend(GameStarttask_handler);
	vTaskSuspend(GameSetuptask_handler);
	vTaskSuspend(HeartStarttask_handler);
				
	OLED_Clear();
	OLED_Update();
				
	taskEXIT_CRITICAL();
}



void demo(void){	
	
	xTaskCreate((TaskFunction_t) 			start_task,
				( char *	   ) 			"start_task", 
				(configSTACK_DEPTH_TYPE) 	START_TASK_STACK_SIZE,
				(void * ) 					NULL,
				(UBaseType_t) 				START_TASK_PRIO,
				(TaskHandle_t * ) 			&start_task_handler );
	vTaskStartScheduler();
}

void Watch_Init(void){
	LED_Init();
	OLED_Init();
	Key_Init();
	Delay_Init();
	RTC_Init();
	AD_Init();
	AHT10_I2C_Init();
}
